import os

# os.system('python main.py --phase 1 --district xixiangxian --year 2017')
# os.system('python main.py --phase 1 --district xixiangxian --year 2019')
# os.system('python main.py --phase 1 --district xixiangxian --year 2021')
# os.system('python main.py --phase 1 --district xixiangxian --year 2023')

# os.system('python main.py --phase 1 --district danfengxian  --year 2017')
# os.system('python main.py --phase 1 --district danfengxian --year 2019')
# os.system('python main.py --phase 1 --district  danfengxian --year 2021')
# os.system('python main.py --phase 1 --district  danfengxian --year 2023')

os.system('python main.py --phase 1 --district fuqingshi  --year 2017')
os.system('python main.py --phase 1 --district fuqingshi --year 2019')
os.system('python main.py --phase 1 --district fuqingshi --year 2021')
os.system('python main.py --phase 1 --district fuqingshi --year 2023')

# os.system('python main.py --phase 1 --district gaoyoushi --year 2017')
# os.system('python main.py --phase 1 --district gaoyoushi --year 2019')
# os.system('python main.py --phase 1 --district gaoyoushi --year 2021')
# os.system('python main.py --phase 1 --district gaoyoushi --year 2023')

# os.system('python main.py --phase 1 --district guanghexian --year 2017')
# os.system('python main.py --phase 1 --district guanghexian --year 2019')
# os.system('python main.py --phase 1 --district guanghexian --year 2021')
# os.system('python main.py --phase 1 --district guanghexian --year 2023')

# os.system('python main.py --phase 1 --district honghexian --year 2017')
# os.system('python main.py --phase 1 --district honghexian --year 2019')
# os.system('python main.py --phase 1 --district honghexian --year 2021')
# os.system('python main.py --phase 1 --district honghexian --year 2023')

# os.system('python main.py --phase 1 --district jiangzixian --year 2017')
# os.system('python main.py --phase 1 --district jiangzixian --year 2019')
# os.system('python main.py --phase 1 --district jiangzixian --year 2021')
# os.system('python main.py --phase 1 --district jiangzixian --year 2023')

# os.system('python main.py --phase 1 --district jingyuxian --year 2017')
# os.system('python main.py --phase 1 --district jingyuxian --year 2019')
# os.system('python main.py --phase 1 --district jingyuxian --year 2021')
# os.system('python main.py --phase 1 --district jingyuxian --year 2023')

# os.system('python main.py --phase 1 --district jinjiangshi --year 2017')
# os.system('python main.py --phase 1 --district jinjiangshi --year 2019')
# os.system('python main.py --phase 1 --district jinjiangshi --year 2021')
# os.system('python main.py --phase 1 --district jinjiangshi --year 2023')

# os.system('python main.py --phase 1 --district kunshanshi --year 2017')
# os.system('python main.py --phase 1 --district kunshanshi --year 2019')
# os.system('python main.py --phase 1 --district kunshanshi --year 2021')
# os.system('python main.py --phase 1 --district kunshanshi --year 2023')

# os.system('python main.py --phase 1 --district liboxian --year 2017')
# os.system('python main.py --phase 1 --district liboxian --year 2019')
# os.system('python main.py --phase 1 --district liboxian --year 2021')
# os.system('python main.py --phase 1 --district liboxian --year 2023')

# os.system('python main.py --phase 1 --district linquanxian --year 2017')
# os.system('python main.py --phase 1 --district  linquanxian --year 2019')
# os.system('python main.py --phase 1 --district linquanxian  --year 2021')
# os.system('python main.py --phase 1 --district linquanxian  --year 2023')

# os.system('python main.py --phase 1 --district pinghushi --year 2017')
# os.system('python main.py --phase 1 --district pinghushi --year 2019')
# os.system('python main.py --phase 1 --district pinghushi --year 2021')
# os.system('python main.py --phase 1 --district pinghushi --year 2023')

# os.system('python main.py --phase 1 --district shufuxian --year 2017')
# os.system('python main.py --phase 1 --district shufuxian --year 2019')
# os.system('python main.py --phase 1 --district  shufuxian --year 2021')
# os.system('python main.py --phase 1 --district shufuxian --year 2023')

# os.system('python main.py --phase 1 --district zhangjiagangshi --year 2017')
# os.system('python main.py --phase 1 --district zhangjiagangshi --year 2019')
# os.system('python main.py --phase 1 --district zhangjiagangshi --year 2021')
# os.system('python main.py --phase 1 --district zhangjiagangshi --year 2023')