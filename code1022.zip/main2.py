import shp2txt
import mapcompare_GE
import mapcompare_GE_0001
import average_statistics


# shp2txt.main()
mapcompare_GE.main()
mapcompare_GE_0001.main()
average_statistics.main()